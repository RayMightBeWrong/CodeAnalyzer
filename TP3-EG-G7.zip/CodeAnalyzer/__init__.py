"""CodeAnalyzer Package"""

from __main__ import main
__version__ = "1.0"

if __name__ == '__main__':
    # execute only if run as the entry point into the program
    main()